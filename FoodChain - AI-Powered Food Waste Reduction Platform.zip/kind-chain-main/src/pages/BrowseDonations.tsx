import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import Navbar from "@/components/Navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Package, MapPin, Clock, Search, ImageIcon } from "lucide-react";

const BrowseDonations = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [donations, setDonations] = useState<any[]>([]);
  const [ngo, setNgo] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [searchCity, setSearchCity] = useState("");
  const [filterType, setFilterType] = useState("all");

  useEffect(() => {
    fetchNGOAndDonations();
  }, [user]);

  const fetchNGOAndDonations = async () => {
    if (!user) return;

    // Fetch NGO profile
    const { data: ngoData } = await supabase
      .from('ngos')
      .select('*')
      .eq('user_id', user.id)
      .single();

    if (!ngoData) {
      navigate('/ngo-setup');
      return;
    }

    setNgo(ngoData);

    // Fetch available donations
    let query = supabase
      .from('food_donations')
      .select('*')
      .eq('status', 'available')
      .order('created_at', { ascending: false });

    if (searchCity) {
      query = query.ilike('city', `%${searchCity}%`);
    }

    if (filterType !== 'all') {
      query = query.eq('food_type', filterType);
    }

    const { data, error } = await query;

    if (!error && data) {
      setDonations(data);
    }
    setLoading(false);
  };

  const handleRequest = async (donationId: string, donorId: string) => {
    if (!ngo) return;

    const { error } = await supabase
      .from('donation_requests')
      .insert({
        donation_id: donationId,
        ngo_id: ngo.id,
        donor_id: donorId,
        status: 'pending'
      });

    if (error) {
      toast({
        title: "Error",
        description: "Failed to request donation. Please try again.",
        variant: "destructive"
      });
    } else {
      toast({
        title: "Request Sent!",
        description: "The donor will be notified of your request."
      });
      fetchNGOAndDonations();
    }
  };

  const getExpiryColor = (risk: string) => {
    switch (risk) {
      case 'high': return 'border-red-500 text-red-500';
      case 'medium': return 'border-amber-500 text-amber-500';
      default: return 'border-green-500 text-green-500';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Browse Food Donations</h1>
          <p className="text-muted-foreground">Find available food donations in your area</p>
        </div>

        {/* Filters */}
        <Card className="border-2 mb-8">
          <CardContent className="pt-6">
            <div className="grid md:grid-cols-3 gap-4">
              <div className="relative">
                <Search className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
                <Input
                  placeholder="Search by city..."
                  value={searchCity}
                  onChange={(e) => setSearchCity(e.target.value)}
                  className="pl-10"
                />
              </div>
              <div>
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Food Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="cooked">Cooked Food</SelectItem>
                    <SelectItem value="packaged">Packaged Food</SelectItem>
                    <SelectItem value="raw">Raw Ingredients</SelectItem>
                    <SelectItem value="baked">Baked Goods</SelectItem>
                    <SelectItem value="produce">Fresh Produce</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Button onClick={fetchNGOAndDonations} className="w-full">
                  Apply Filters
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Donations List */}
        {loading ? (
          <div className="grid gap-6">
            {[1, 2, 3].map((i) => (
              <Card key={i} className="border-2">
                <CardHeader>
                  <Skeleton className="h-8 w-3/4 mb-2" />
                  <div className="flex gap-2">
                    <Skeleton className="h-6 w-20" />
                    <Skeleton className="h-6 w-24" />
                  </div>
                </CardHeader>
                <CardContent>
                  <Skeleton className="h-4 w-full mb-4" />
                  <div className="grid md:grid-cols-3 gap-4 mb-6">
                    <Skeleton className="h-6 w-full" />
                    <Skeleton className="h-6 w-full" />
                    <Skeleton className="h-6 w-full" />
                  </div>
                  <Skeleton className="h-10 w-40" />
                </CardContent>
              </Card>
            ))}
          </div>
        ) : donations.length === 0 ? (
          <Card className="border-2">
            <CardContent className="py-12 text-center">
              <Package className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-semibold mb-2">No donations found</h3>
              <p className="text-muted-foreground">Try adjusting your filters</p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6">
            {donations.map((donation) => (
              <Card key={donation.id} className="border-2 hover:shadow-soft transition-all">
                <div className="grid md:grid-cols-[300px,1fr] gap-0">
                  {/* Image Section */}
                  <div className="bg-muted/30 relative overflow-hidden">
                    {donation.image_url ? (
                      <img 
                        src={donation.image_url} 
                        alt={donation.food_name}
                        className="w-full h-full object-cover min-h-[250px] md:min-h-full"
                      />
                    ) : (
                      <div className="flex items-center justify-center h-full min-h-[250px] md:min-h-full">
                        <ImageIcon className="w-16 h-16 text-muted-foreground/30" />
                      </div>
                    )}
                    <div className="absolute top-3 left-3 flex gap-2">
                      <Badge className="backdrop-blur-sm bg-background/80">
                        {donation.food_type}
                      </Badge>
                      <Badge 
                        variant="outline" 
                        className={`backdrop-blur-sm bg-background/80 ${getExpiryColor(donation.expiry_risk)}`}
                      >
                        {donation.expiry_risk} risk
                      </Badge>
                    </div>
                  </div>

                  {/* Content Section */}
                  <div>
                    <CardHeader>
                      <CardTitle className="text-2xl">{donation.food_name}</CardTitle>
                      {donation.description && (
                        <CardDescription className="text-base mt-2">
                          {donation.description}
                        </CardDescription>
                      )}
                    </CardHeader>
                    <CardContent>
                      <div className="grid md:grid-cols-3 gap-4 mb-6">
                        <div className="flex items-center gap-2">
                          <Package className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">
                            {donation.quantity} {donation.unit}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          <MapPin className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">{donation.city}, {donation.state}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span className="text-sm">
                            Expires: {new Date(donation.expiry_date).toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                      <Button
                        onClick={() => handleRequest(donation.id, donation.donor_id)}
                        className="bg-gradient-hero w-full md:w-auto"
                      >
                        Request This Donation
                      </Button>
                    </CardContent>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default BrowseDonations;

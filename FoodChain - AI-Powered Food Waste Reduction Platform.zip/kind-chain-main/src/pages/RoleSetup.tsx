import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { useUserRole } from "@/hooks/useUserRole";
import { Loader2 } from "lucide-react";

const RoleSetup = () => {
  const navigate = useNavigate();
  const { user, loading: authLoading } = useAuth();
  const { isDonor, isNGO, loading: roleLoading } = useUserRole();

  useEffect(() => {
    if (!authLoading && !roleLoading) {
      if (!user) {
        navigate('/auth');
        return;
      }

      if (isNGO) {
        navigate('/ngo-setup');
      } else if (isDonor) {
        navigate('/dashboard');
      }
    }
  }, [user, isDonor, isNGO, authLoading, roleLoading, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-secondary/30 to-background">
      <div className="text-center space-y-4">
        <Loader2 className="w-12 h-12 animate-spin mx-auto text-primary" />
        <h2 className="text-2xl font-bold">Setting up your account...</h2>
        <p className="text-muted-foreground">Please wait while we prepare your dashboard</p>
      </div>
    </div>
  );
};

export default RoleSetup;

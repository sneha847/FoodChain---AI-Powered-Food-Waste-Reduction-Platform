import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "@/hooks/useAuth";
import { supabase } from "@/integrations/supabase/client";
import Navbar from "@/components/Navbar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { useImageUpload } from "@/hooks/useImageUpload";
import { Loader2, Upload, X } from "lucide-react";
import { z } from "zod";

const donationSchema = z.object({
  food_name: z.string().trim().min(2, "Food name is required").max(200),
  food_type: z.enum(['cooked', 'raw', 'packaged', 'beverages']),
  quantity: z.number().min(0.1, "Quantity must be at least 0.1").max(10000),
  unit: z.enum(['kg', 'liters', 'servings', 'pieces']),
  description: z.string().trim().max(1000).optional(),
  expiry_date: z.string().min(1, "Expiry date is required"),
  address: z.string().trim().min(5, "Address is required").max(500),
  city: z.string().trim().min(2, "City is required").max(100),
  state: z.string().trim().min(2, "State is required").max(100),
  pincode: z.string().trim().regex(/^\d{5,10}$/, "Invalid pincode format")
});

const Donate = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const { uploadImage, uploading } = useImageUpload();
  const [loading, setLoading] = useState(false);
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    food_name: "",
    food_type: "cooked",
    quantity: "",
    unit: "kg",
    description: "",
    expiry_date: "",
    address: "",
    city: "",
    state: "",
    pincode: ""
  });

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setImageFile(file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const removeImage = () => {
    setImageFile(null);
    setImagePreview(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast({
        title: "Authentication required",
        description: "Please sign in to create a donation",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);

    try {
      // Validate form data
      const validated = donationSchema.parse({
        ...formData,
        quantity: parseFloat(formData.quantity)
      });

      // Upload image if provided
      let imageUrl: string | null = null;
      if (imageFile) {
        imageUrl = await uploadImage(imageFile, user.id);
        if (!imageUrl) {
          setLoading(false);
          return;
        }
      }

      // Calculate expiry risk
      const expiryDate = new Date(validated.expiry_date);
      const now = new Date();
      const hoursDiff = (expiryDate.getTime() - now.getTime()) / (1000 * 60 * 60);
      
      let expiry_risk = 'low';
      if (hoursDiff < 6) expiry_risk = 'high';
      else if (hoursDiff < 24) expiry_risk = 'medium';

      const { error } = await supabase
        .from('food_donations')
        .insert({
          donor_id: user.id,
          food_name: validated.food_name,
          food_type: validated.food_type,
          quantity: validated.quantity,
          unit: validated.unit,
          description: validated.description || null,
          expiry_date: validated.expiry_date,
          expiry_risk,
          address: validated.address,
          city: validated.city,
          state: validated.state,
          pincode: validated.pincode,
          image_url: imageUrl,
          status: 'available'
        });

      if (error) {
        throw new Error(error.message);
      }

      toast({
        title: "Success!",
        description: "Your food donation has been listed."
      });
      navigate('/dashboard');
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Validation error",
          description: error.errors[0].message,
          variant: "destructive"
        });
      } else if (error instanceof Error) {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive"
        });
      }
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <div className="container mx-auto px-4 py-8 max-w-3xl">
        <Card className="border-2">
          <CardHeader>
            <CardTitle className="text-3xl">Donate Food</CardTitle>
            <CardDescription>Share your surplus food with those in need</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Image Upload */}
              <div className="space-y-2">
                <Label>Food Image (Optional)</Label>
                {!imagePreview ? (
                  <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-primary/50 transition-colors cursor-pointer">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleImageChange}
                      className="hidden"
                      id="image-upload"
                    />
                    <label htmlFor="image-upload" className="cursor-pointer flex flex-col items-center gap-2">
                      <Upload className="h-10 w-10 text-muted-foreground" />
                      <p className="text-sm text-muted-foreground">
                        Click to upload food image
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Max 5MB • JPG, PNG, WEBP
                      </p>
                    </label>
                  </div>
                ) : (
                  <div className="relative rounded-lg overflow-hidden border-2 border-border">
                    <img 
                      src={imagePreview} 
                      alt="Food preview" 
                      className="w-full h-64 object-cover"
                    />
                    <Button
                      type="button"
                      variant="destructive"
                      size="icon"
                      className="absolute top-2 right-2"
                      onClick={removeImage}
                    >
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="food_name">Food Name *</Label>
                  <Input
                    id="food_name"
                    value={formData.food_name}
                    onChange={(e) => handleChange('food_name', e.target.value)}
                    required
                    placeholder="e.g., Rice, Curry, Bread"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="food_type">Food Type *</Label>
                  <Select value={formData.food_type} onValueChange={(value) => handleChange('food_type', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="cooked">Cooked Food</SelectItem>
                      <SelectItem value="packaged">Packaged Food</SelectItem>
                      <SelectItem value="raw">Raw Ingredients</SelectItem>
                      <SelectItem value="baked">Baked Goods</SelectItem>
                      <SelectItem value="produce">Fresh Produce</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="quantity">Quantity *</Label>
                  <Input
                    id="quantity"
                    type="number"
                    step="0.01"
                    value={formData.quantity}
                    onChange={(e) => handleChange('quantity', e.target.value)}
                    required
                    placeholder="e.g., 5"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="unit">Unit *</Label>
                  <Select value={formData.unit} onValueChange={(value) => handleChange('unit', value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="kg">Kilograms</SelectItem>
                      <SelectItem value="portions">Portions</SelectItem>
                      <SelectItem value="plates">Plates</SelectItem>
                      <SelectItem value="boxes">Boxes</SelectItem>
                      <SelectItem value="bags">Bags</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="expiry_date">Best Before Date & Time *</Label>
                  <Input
                    id="expiry_date"
                    type="datetime-local"
                    value={formData.expiry_date}
                    onChange={(e) => handleChange('expiry_date', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={formData.description}
                    onChange={(e) => handleChange('description', e.target.value)}
                    placeholder="Additional details about the food..."
                    rows={3}
                  />
                </div>

                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="address">Pickup Address *</Label>
                  <Input
                    id="address"
                    value={formData.address}
                    onChange={(e) => handleChange('address', e.target.value)}
                    required
                    placeholder="Street address"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => handleChange('city', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="state">State *</Label>
                  <Input
                    id="state"
                    value={formData.state}
                    onChange={(e) => handleChange('state', e.target.value)}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="pincode">Pincode *</Label>
                  <Input
                    id="pincode"
                    value={formData.pincode}
                    onChange={(e) => handleChange('pincode', e.target.value)}
                    required
                    placeholder="e.g., 400001"
                  />
                </div>
              </div>

              <div className="flex gap-4">
                <Button type="submit" disabled={loading || uploading} className="bg-gradient-hero flex-1">
                  {loading || uploading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      {uploading ? "Uploading..." : "Creating..."}
                    </>
                  ) : (
                    'Create Donation'
                  )}
                </Button>
                <Button type="button" variant="outline" onClick={() => navigate('/dashboard')}>
                  Cancel
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Donate;

import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Loader2 } from "lucide-react";
import { z } from "zod";

const ngoSchema = z.object({
  organizationName: z.string().trim().min(2, "Organization name is required").max(200),
  registrationNumber: z.string().trim().max(100).optional(),
  address: z.string().trim().min(5, "Address is required").max(500),
  city: z.string().trim().min(2, "City is required").max(100),
  state: z.string().trim().min(2, "State is required").max(100),
  pincode: z.string().trim().min(5, "Valid pincode required").max(10),
  contactPerson: z.string().trim().min(2, "Contact person name is required").max(100),
  contactEmail: z.string().trim().email("Valid email required").max(255),
  contactPhone: z.string().trim().min(10, "Valid phone number required").max(15),
  description: z.string().trim().max(1000).optional(),
  capacityPerDay: z.number().min(1, "Capacity must be at least 1").optional()
});

const NGOSetup = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);

  const [formData, setFormData] = useState({
    organizationName: "",
    registrationNumber: "",
    address: "",
    city: "",
    state: "",
    pincode: "",
    contactPerson: "",
    contactEmail: "",
    contactPhone: "",
    description: "",
    capacityPerDay: ""
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);

    try {
      const validated = ngoSchema.parse({
        ...formData,
        capacityPerDay: formData.capacityPerDay ? parseInt(formData.capacityPerDay) : undefined
      });

      const { error } = await supabase.from('ngos').insert({
        user_id: user.id,
        organization_name: validated.organizationName,
        registration_number: validated.registrationNumber || null,
        address: validated.address,
        city: validated.city,
        state: validated.state,
        pincode: validated.pincode,
        contact_person: validated.contactPerson,
        contact_email: validated.contactEmail,
        contact_phone: validated.contactPhone,
        description: validated.description || null,
        capacity_per_day: validated.capacityPerDay
      });

      if (error) {
        toast({
          title: "Error",
          description: error.message,
          variant: "destructive"
        });
      } else {
        toast({
          title: "NGO registered!",
          description: "Your organization profile has been created."
        });
        navigate('/dashboard');
      }
    } catch (error) {
      if (error instanceof z.ZodError) {
        toast({
          title: "Validation error",
          description: error.errors[0].message,
          variant: "destructive"
        });
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-secondary/30 to-background py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <Card className="shadow-strong border-2">
          <CardHeader>
            <CardTitle className="text-3xl">NGO Registration</CardTitle>
            <CardDescription>Complete your organization profile to start receiving food donations</CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="organizationName">Organization Name *</Label>
                <Input
                  id="organizationName"
                  value={formData.organizationName}
                  onChange={(e) => setFormData({ ...formData, organizationName: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="registrationNumber">Registration Number</Label>
                <Input
                  id="registrationNumber"
                  value={formData.registrationNumber}
                  onChange={(e) => setFormData({ ...formData, registrationNumber: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="address">Address *</Label>
                <Textarea
                  id="address"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="city">City *</Label>
                  <Input
                    id="city"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="state">State *</Label>
                  <Input
                    id="state"
                    value={formData.state}
                    onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="pincode">Pincode *</Label>
                <Input
                  id="pincode"
                  value={formData.pincode}
                  onChange={(e) => setFormData({ ...formData, pincode: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="contactPerson">Contact Person *</Label>
                <Input
                  id="contactPerson"
                  value={formData.contactPerson}
                  onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="contactEmail">Contact Email *</Label>
                  <Input
                    id="contactEmail"
                    type="email"
                    value={formData.contactEmail}
                    onChange={(e) => setFormData({ ...formData, contactEmail: e.target.value })}
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="contactPhone">Contact Phone *</Label>
                  <Input
                    id="contactPhone"
                    value={formData.contactPhone}
                    onChange={(e) => setFormData({ ...formData, contactPhone: e.target.value })}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="description">Description</Label>
                <Textarea
                  id="description"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Tell us about your organization and who you serve..."
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="capacityPerDay">Daily Capacity (meals)</Label>
                <Input
                  id="capacityPerDay"
                  type="number"
                  value={formData.capacityPerDay}
                  onChange={(e) => setFormData({ ...formData, capacityPerDay: e.target.value })}
                  placeholder="How many people can you serve daily?"
                />
              </div>

              <Button type="submit" className="w-full bg-gradient-hero" size="lg" disabled={loading}>
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Registering...
                  </>
                ) : (
                  'Complete Registration'
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default NGOSetup;

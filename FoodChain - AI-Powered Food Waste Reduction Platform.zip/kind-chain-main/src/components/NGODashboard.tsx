import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Package, Bell, Search, TrendingUp } from "lucide-react";

const NGODashboard = () => {
  const { user } = useAuth();
  const [ngo, setNgo] = useState<any>(null);
  const [stats, setStats] = useState({ availableDonations: 0, activeRequests: 0, completed: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      if (!user) return;

      // Fetch NGO profile
      const { data: ngoData } = await supabase
        .from('ngos')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (ngoData) {
        setNgo(ngoData);

        // Fetch stats
        const { data: availableDonations } = await supabase
          .from('food_donations')
          .select('*', { count: 'exact', head: true })
          .eq('status', 'available');

        const { data: activeRequests } = await supabase
          .from('donation_requests')
          .select('*', { count: 'exact', head: true })
          .eq('ngo_id', ngoData.id)
          .in('status', ['pending', 'accepted']);

        const { data: completedRequests } = await supabase
          .from('donation_requests')
          .select('*', { count: 'exact', head: true })
          .eq('ngo_id', ngoData.id)
          .eq('status', 'completed');

        setStats({
          availableDonations: (availableDonations as any)?.count || 0,
          activeRequests: (activeRequests as any)?.count || 0,
          completed: (completedRequests as any)?.count || 0
        });
      }

      setLoading(false);
    };

    fetchData();
  }, [user]);

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <p className="text-center text-muted-foreground">Loading dashboard...</p>
      </div>
    );
  }

  if (!ngo) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card className="border-2">
          <CardHeader>
            <CardTitle>Complete Your NGO Profile</CardTitle>
            <CardDescription>Set up your organization to start receiving donations</CardDescription>
          </CardHeader>
          <CardContent>
            <Link to="/ngo-setup">
              <Button className="bg-gradient-hero">Complete Profile</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">{ngo.organization_name}</h1>
          <p className="text-muted-foreground mt-2">NGO Dashboard</p>
        </div>
        <Link to="/browse-donations">
          <Button className="bg-gradient-hero shadow-soft">
            <Search className="w-4 h-4 mr-2" />
            Browse Donations
          </Button>
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="border-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Available Donations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <Package className="w-8 h-8 text-primary" />
              <div className="text-3xl font-bold">{stats.availableDonations}</div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Requests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <Bell className="w-8 h-8 text-accent" />
              <div className="text-3xl font-bold">{stats.activeRequests}</div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Completed Pickups</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <TrendingUp className="w-8 h-8 text-green-500" />
              <div className="text-3xl font-bold">{stats.completed}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* NGO Profile */}
      <Card className="border-2 mb-8">
        <CardHeader>
          <CardTitle>Organization Profile</CardTitle>
          <CardDescription>Your organization details</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <h3 className="font-semibold text-sm text-muted-foreground mb-1">Contact Person</h3>
              <p>{ngo.contact_person}</p>
            </div>
            <div>
              <h3 className="font-semibold text-sm text-muted-foreground mb-1">Contact Email</h3>
              <p>{ngo.contact_email}</p>
            </div>
            <div>
              <h3 className="font-semibold text-sm text-muted-foreground mb-1">Contact Phone</h3>
              <p>{ngo.contact_phone}</p>
            </div>
            <div>
              <h3 className="font-semibold text-sm text-muted-foreground mb-1">Daily Capacity</h3>
              <p>{ngo.capacity_per_day || 'Not specified'} meals</p>
            </div>
            <div className="md:col-span-2">
              <h3 className="font-semibold text-sm text-muted-foreground mb-1">Address</h3>
              <p>{ngo.address}, {ngo.city}, {ngo.state} - {ngo.pincode}</p>
            </div>
            {ngo.description && (
              <div className="md:col-span-2">
                <h3 className="font-semibold text-sm text-muted-foreground mb-1">About</h3>
                <p className="text-sm">{ngo.description}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="border-2 hover:shadow-soft transition-all cursor-pointer" onClick={() => window.location.href = '/browse-donations'}>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="w-5 h-5 text-primary" />
              Browse Available Food
            </CardTitle>
            <CardDescription>Find surplus food available for pickup in your area</CardDescription>
          </CardHeader>
        </Card>

        <Card className="border-2 hover:shadow-soft transition-all cursor-pointer">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-accent" />
              View Notifications
            </CardTitle>
            <CardDescription>Check updates on your donation requests and pickups</CardDescription>
          </CardHeader>
        </Card>
      </div>
    </div>
  );
};

export default NGODashboard;

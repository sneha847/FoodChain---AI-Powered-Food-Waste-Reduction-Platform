import { Upload, Sparkles, Truck, Heart } from "lucide-react";

const steps = [
  {
    icon: Upload,
    title: "Upload Food Details",
    description: "Donors upload food images or metadata. Our AI analyzes and predicts expiry risk.",
    color: "text-primary",
  },
  {
    icon: Sparkles,
    title: "Smart Matching",
    description: "System matches donations with NGOs based on needs, location, and urgency.",
    color: "text-accent",
  },
  {
    icon: Truck,
    title: "Coordinate Pickup",
    description: "NGOs receive alerts, accept donations, and schedule efficient pickups.",
    color: "text-primary",
  },
  {
    icon: Heart,
    title: "Track Impact",
    description: "Monitor food saved, people fed, and environmental impact through your dashboard.",
    color: "text-accent",
  },
];

const HowItWorks = () => {
  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground">
            How{" "}
            <span className="bg-gradient-hero bg-clip-text text-transparent">
              FoodChain Works
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Four simple steps to transform surplus food into impact.
          </p>
        </div>

        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {steps.map((step, index) => (
              <div key={index} className="relative group">
                {/* Connector line */}
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-16 left-[60%] w-[80%] h-0.5 bg-gradient-to-r from-primary/30 to-transparent"></div>
                )}
                
                <div className="text-center space-y-4">
                  {/* Icon circle */}
                  <div className="relative mx-auto w-32 h-32 rounded-full bg-gradient-to-br from-secondary to-muted flex items-center justify-center group-hover:scale-110 transition-transform shadow-soft">
                    <div className="absolute inset-0 rounded-full bg-gradient-to-br from-primary/20 to-accent/20 animate-pulse"></div>
                    <step.icon className={`w-14 h-14 ${step.color} relative z-10`} />
                    
                    {/* Step number */}
                    <div className="absolute -top-3 -right-3 w-10 h-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold text-lg shadow-strong">
                      {index + 1}
                    </div>
                  </div>

                  {/* Content */}
                  <h3 className="text-xl font-bold text-foreground">{step.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{step.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HowItWorks;

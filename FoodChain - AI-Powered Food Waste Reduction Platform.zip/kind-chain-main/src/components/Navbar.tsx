import { Link } from "react-router-dom";
import { Button } from "./ui/button";
import { useAuth } from "@/hooks/useAuth";
import { useUserRole } from "@/hooks/useUserRole";
import { Leaf, Menu } from "lucide-react";
import { Sheet, SheetContent, SheetTrigger } from "./ui/sheet";

const Navbar = () => {
  const { user, signOut } = useAuth();
  const { isDonor, isNGO } = useUserRole();

  return (
    <nav className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2">
          <div className="w-10 h-10 rounded-xl bg-gradient-hero flex items-center justify-center shadow-soft">
            <Leaf className="w-6 h-6 text-white" />
          </div>
          <span className="text-xl font-bold">FoodChain</span>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center gap-6">
          {user ? (
            <>
              <Link to="/dashboard" className="text-sm font-medium hover:text-primary transition-colors">
                Dashboard
              </Link>
              {isDonor && (
                <Link to="/donate" className="text-sm font-medium hover:text-primary transition-colors">
                  Donate Food
                </Link>
              )}
              {isNGO && (
                <Link to="/browse-donations" className="text-sm font-medium hover:text-primary transition-colors">
                  Browse Donations
                </Link>
              )}
              <Button variant="outline" onClick={signOut}>
                Sign Out
              </Button>
            </>
          ) : (
            <>
              <Link to="/#features" className="text-sm font-medium hover:text-primary transition-colors">
                Features
              </Link>
              <Link to="/#how-it-works" className="text-sm font-medium hover:text-primary transition-colors">
                How It Works
              </Link>
              <Link to="/auth">
                <Button className="bg-gradient-hero">
                  Get Started
                </Button>
              </Link>
            </>
          )}
        </div>

        {/* Mobile Navigation */}
        <Sheet>
          <SheetTrigger asChild className="md:hidden">
            <Button variant="ghost" size="icon">
              <Menu className="h-6 w-6" />
            </Button>
          </SheetTrigger>
          <SheetContent>
            <div className="flex flex-col gap-4 mt-8">
              {user ? (
                <>
                  <Link to="/dashboard" className="text-lg font-medium hover:text-primary transition-colors">
                    Dashboard
                  </Link>
                  {isDonor && (
                    <Link to="/donate" className="text-lg font-medium hover:text-primary transition-colors">
                      Donate Food
                    </Link>
                  )}
                  {isNGO && (
                    <Link to="/browse-donations" className="text-lg font-medium hover:text-primary transition-colors">
                      Browse Donations
                    </Link>
                  )}
                  <Button variant="outline" onClick={signOut} className="w-full">
                    Sign Out
                  </Button>
                </>
              ) : (
                <>
                  <Link to="/#features" className="text-lg font-medium hover:text-primary transition-colors">
                    Features
                  </Link>
                  <Link to="/#how-it-works" className="text-lg font-medium hover:text-primary transition-colors">
                    How It Works
                  </Link>
                  <Link to="/auth">
                    <Button className="bg-gradient-hero w-full">
                      Get Started
                    </Button>
                  </Link>
                </>
              )}
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </nav>
  );
};

export default Navbar;

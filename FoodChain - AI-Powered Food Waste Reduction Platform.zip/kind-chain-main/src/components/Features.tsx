import { Brain, MapPin, BarChart3, Bell, Shield, Zap } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const features = [
  {
    icon: Brain,
    title: "AI Expiry Prediction",
    description: "Upload food images and get instant expiry predictions using advanced ML models.",
    gradient: "from-primary to-primary/70",
  },
  {
    icon: MapPin,
    title: "Smart Matching",
    description: "Automatically connect donors with the nearest NGOs based on needs and location.",
    gradient: "from-accent to-accent/70",
  },
  {
    icon: BarChart3,
    title: "Impact Analytics",
    description: "Track food saved, carbon footprint reduced, and lives impacted in real-time.",
    gradient: "from-primary to-accent",
  },
  {
    icon: Bell,
    title: "Real-Time Alerts",
    description: "Instant notifications when food is available or when donations are needed.",
    gradient: "from-accent to-primary",
  },
  {
    icon: Shield,
    title: "Multi-Role Access",
    description: "Separate dashboards for donors, NGOs, and administrators with secure authentication.",
    gradient: "from-primary/70 to-primary",
  },
  {
    icon: Zap,
    title: "Quick Distribution",
    description: "Streamlined pickup process ensures food reaches beneficiaries before expiry.",
    gradient: "from-accent/70 to-accent",
  },
];

const Features = () => {
  return (
    <section className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16 space-y-4 animate-fade-in">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground">
            Powerful Features for{" "}
            <span className="bg-gradient-hero bg-clip-text text-transparent">
              Maximum Impact
            </span>
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Everything you need to make food distribution efficient, transparent, and impactful.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="border-2 hover:shadow-strong transition-all duration-300 hover:-translate-y-1 bg-card"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <CardHeader>
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${feature.gradient} flex items-center justify-center mb-4 shadow-soft`}>
                  <feature.icon className="w-7 h-7 text-white" />
                </div>
                <CardTitle className="text-2xl">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-base leading-relaxed">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;

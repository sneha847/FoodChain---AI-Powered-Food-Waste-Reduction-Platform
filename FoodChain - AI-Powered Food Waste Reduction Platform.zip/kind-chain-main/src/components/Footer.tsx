import { Leaf } from "lucide-react";

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-muted/30 border-t border-border py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-6xl mx-auto">
          {/* Logo and tagline */}
          <div className="flex items-center justify-center gap-3 mb-8">
            <div className="w-10 h-10 rounded-xl bg-gradient-hero flex items-center justify-center shadow-soft">
              <Leaf className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-foreground">FoodChain</span>
          </div>

          <div className="text-center space-y-4">
            <p className="text-muted-foreground max-w-md mx-auto">
              Connecting surplus food with communities in need through AI-powered smart distribution.
            </p>
            
            {/* Links */}
            <div className="flex flex-wrap justify-center gap-6 text-sm">
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">About Us</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">How It Works</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">For Donors</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">For NGOs</a>
              <a href="#" className="text-muted-foreground hover:text-primary transition-colors">Contact</a>
            </div>

            {/* Copyright */}
            <div className="pt-8 border-t border-border text-sm text-muted-foreground">
              © {currentYear} FoodChain. Reducing food waste, one donation at a time.
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

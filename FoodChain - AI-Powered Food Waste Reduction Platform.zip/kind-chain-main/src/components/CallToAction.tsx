import { Button } from "@/components/ui/button";
import { ArrowRight, Building2, Users } from "lucide-react";

const CallToAction = () => {
  return (
    <section className="py-24 bg-gradient-to-br from-primary/5 via-accent/5 to-primary/5 relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-primary rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-1/4 w-96 h-96 bg-accent rounded-full blur-3xl"></div>
      </div>

      <div className="container mx-auto px-4 relative z-10">
        <div className="max-w-5xl mx-auto">
          {/* Main CTA */}
          <div className="text-center mb-16 space-y-6">
            <h2 className="text-4xl md:text-5xl font-bold text-foreground">
              Ready to Make a{" "}
              <span className="bg-gradient-hero bg-clip-text text-transparent">
                Difference?
              </span>
            </h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              Join thousands of donors and NGOs already using FoodChain to reduce waste and feed communities.
            </p>
          </div>

          {/* Two column CTAs */}
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            {/* Donor CTA */}
            <div className="bg-card rounded-3xl p-8 border-2 border-primary/20 hover:border-primary/40 transition-all shadow-soft hover:shadow-strong group">
              <div className="w-16 h-16 rounded-2xl bg-gradient-hero flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3">For Donors</h3>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Restaurants, hotels, and businesses - turn your surplus food into impact. Track donations and see the difference you make.
              </p>
              <Button 
                className="w-full bg-gradient-hero hover:opacity-90 transition-opacity text-lg py-6"
                onClick={() => window.location.href = '/auth'}
              >
                Start Donating Today
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>

            {/* NGO CTA */}
            <div className="bg-card rounded-3xl p-8 border-2 border-accent/20 hover:border-accent/40 transition-all shadow-soft hover:shadow-strong group">
              <div className="w-16 h-16 rounded-2xl bg-gradient-accent flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-2xl font-bold text-foreground mb-3">For NGOs</h3>
              <p className="text-muted-foreground mb-6 leading-relaxed">
                Access real-time food donations, manage pickups efficiently, and serve more people in your community with less effort.
              </p>
              <Button 
                className="w-full bg-gradient-accent hover:opacity-90 transition-opacity text-lg py-6"
                onClick={() => window.location.href = '/auth'}
              >
                Register Your NGO
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </div>

          {/* Trust indicators */}
          <div className="text-center mt-16 pt-12 border-t border-border">
            <p className="text-sm text-muted-foreground mb-6">Trusted by leading organizations</p>
            <div className="flex flex-wrap justify-center items-center gap-8 opacity-50">
              <div className="text-xl font-bold text-foreground">Feeding India</div>
              <div className="text-xl font-bold text-foreground">Food Bank Network</div>
              <div className="text-xl font-bold text-foreground">Zero Hunger Initiative</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;

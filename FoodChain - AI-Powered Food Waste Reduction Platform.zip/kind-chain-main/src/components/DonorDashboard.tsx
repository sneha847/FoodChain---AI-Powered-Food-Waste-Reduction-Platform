import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { TrendingDown, Package, Clock, CheckCircle, Plus } from "lucide-react";

const DonorDashboard = () => {
  const { user } = useAuth();
  const [donations, setDonations] = useState<any[]>([]);
  const [stats, setStats] = useState({ total: 0, active: 0, completed: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDonations = async () => {
      if (!user) return;

      const { data, error } = await supabase
        .from('food_donations')
        .select('*')
        .eq('donor_id', user.id)
        .order('created_at', { ascending: false });

      if (!error && data) {
        setDonations(data);
        setStats({
          total: data.length,
          active: data.filter(d => d.status === 'available').length,
          completed: data.filter(d => d.status === 'completed').length
        });
      }
      setLoading(false);
    };

    fetchDonations();

    // Subscribe to real-time updates
    const channel = supabase
      .channel('donor-donations')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'food_donations',
        filter: `donor_id=eq.${user?.id}`
      }, () => {
        fetchDonations();
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user]);

  const statusColors = {
    available: 'bg-primary',
    reserved: 'bg-accent',
    picked_up: 'bg-blue-500',
    completed: 'bg-green-500',
    expired: 'bg-destructive',
    cancelled: 'bg-muted'
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-4xl font-bold">Donor Dashboard</h1>
          <p className="text-muted-foreground mt-2">Manage your food donations and track impact</p>
        </div>
        <Link to="/donate">
          <Button className="bg-gradient-hero shadow-soft">
            <Plus className="w-4 h-4 mr-2" />
            Donate Food
          </Button>
        </Link>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="border-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Donations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <Package className="w-8 h-8 text-primary" />
              <div className="text-3xl font-bold">{stats.total}</div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Donations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <Clock className="w-8 h-8 text-accent" />
              <div className="text-3xl font-bold">{stats.active}</div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-2">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-muted-foreground">Completed</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-3">
              <CheckCircle className="w-8 h-8 text-green-500" />
              <div className="text-3xl font-bold">{stats.completed}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Donations */}
      <Card className="border-2">
        <CardHeader>
          <CardTitle>Recent Donations</CardTitle>
          <CardDescription>Track the status of your food donations</CardDescription>
        </CardHeader>
        <CardContent>
          {loading ? (
            <p className="text-center text-muted-foreground py-8">Loading donations...</p>
          ) : donations.length === 0 ? (
            <div className="text-center py-12">
              <TrendingDown className="w-16 h-16 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-semibold mb-2">No donations yet</h3>
              <p className="text-muted-foreground mb-4">Start making a difference by donating surplus food</p>
              <Link to="/donate">
                <Button className="bg-gradient-hero">Create Your First Donation</Button>
              </Link>
            </div>
          ) : (
            <div className="space-y-4">
              {donations.map((donation) => (
                <div key={donation.id} className="border rounded-lg p-4 hover:shadow-soft transition-all">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold">{donation.food_name}</h3>
                        <Badge className={statusColors[donation.status as keyof typeof statusColors]}>
                          {donation.status}
                        </Badge>
                        <Badge variant="outline" className={
                          donation.expiry_risk === 'high' ? 'border-red-500 text-red-500' :
                          donation.expiry_risk === 'medium' ? 'border-amber-500 text-amber-500' :
                          'border-green-500 text-green-500'
                        }>
                          {donation.expiry_risk} risk
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground mb-2">{donation.description}</p>
                      <div className="flex gap-4 text-sm text-muted-foreground">
                        <span>Type: {donation.food_type}</span>
                        <span>Quantity: {donation.quantity} {donation.unit}</span>
                        <span>Location: {donation.city}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default DonorDashboard;
